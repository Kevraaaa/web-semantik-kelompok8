<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['icon', 'title', 'description', 'href']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['icon', 'title', 'description', 'href']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<a href="<?php echo e($href); ?>" class="group rounded-2xl border border-soft surface p-5 card-hover">
    <div class="flex items-start justify-between"><span class="grid size-11 place-items-center rounded-xl bg-fig-leaf/20 text-xl text-fresh-grown"><?php echo e($icon); ?></span><span class="text-lg text-muted transition group-hover:translate-x-1 group-hover:text-fresh-grown" aria-hidden="true">↗</span></div>
    <h3 class="mt-5 font-display text-xl"><?php echo e($title); ?></h3><p class="mt-2 text-sm leading-6 text-muted"><?php echo e($description); ?></p>
</a>
<?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/components/shortcut-card.blade.php ENDPATH**/ ?>