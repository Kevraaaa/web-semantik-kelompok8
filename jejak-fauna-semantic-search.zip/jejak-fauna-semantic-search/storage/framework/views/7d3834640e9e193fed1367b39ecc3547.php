<?php $__env->startSection('title', 'Profil Saya — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'profile'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page pb-20 pt-10">
    <div class="rounded-3xl border border-soft surface p-6 sm:p-9">
        <div class="flex flex-col gap-5 sm:flex-row sm:items-center"><div class="grid size-20 place-items-center rounded-full bg-fig-leaf/30 font-display text-3xl text-fresh-grown">A</div><div class="flex-1"><p class="eyebrow">Ruang pribadimu</p><h1 class="font-display mt-1 text-3xl" data-profile-name>Ayu Lestari</h1><p class="mt-1 text-sm text-muted" data-profile-email>ayu.lestari@example.test · Bergabung Januari 2026</p></div><a class="btn-secondary" href="<?php echo e(route('report.create')); ?>">＋ Lapor Penemuan</a></div>
        <div class="mt-8 flex gap-2 overflow-x-auto border-b border-soft pb-3" role="tablist" aria-label="Menu profil">
            <button class="profile-tab active" type="button" role="tab" aria-selected="true" data-profile-tab="favorit">Favorit</button>
            <button class="profile-tab" type="button" role="tab" aria-selected="false" data-profile-tab="riwayat">Riwayat Pencarian</button>
            <button class="profile-tab" type="button" role="tab" aria-selected="false" data-profile-tab="laporan-saya">Laporan Saya</button>
            <button class="profile-tab" type="button" role="tab" aria-selected="false" data-profile-tab="aktivitas">Aktivitas</button>
        </div>
    </div>
    <section class="mt-8" data-profile-panel="favorit" role="tabpanel"><div class="mb-5 flex items-center justify-between"><h2 class="font-display text-2xl">Fauna favorit</h2><span class="pill text-xs" data-favorite-count>0 tersimpan</span></div><div class="grid gap-5 sm:grid-cols-2 xl:grid-cols-3" data-profile-favorites></div></section>
    <section class="mt-8 hidden" data-profile-panel="riwayat" role="tabpanel"><h2 class="font-display text-2xl">Riwayat pencarian</h2><div class="mt-5 grid gap-3" data-profile-history></div></section>
    <section class="mt-8 hidden" data-profile-panel="laporan-saya" id="laporan-saya" role="tabpanel"><h2 class="font-display text-2xl">Laporan saya</h2><div class="mt-5 grid gap-3" data-profile-reports></div></section>
    <section class="mt-8 hidden" data-profile-panel="aktivitas" role="tabpanel"><h2 class="font-display text-2xl">Riwayat aktivitas</h2><div class="mt-5 rounded-2xl border border-soft surface p-5" data-profile-activity></div></section>
</section>
<?php if (isset($component)) { $__componentOriginal4c8712d109ee532d154e34556ce7da7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c8712d109ee532d154e34556ce7da7e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.compare-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('compare-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c8712d109ee532d154e34556ce7da7e)): ?>
<?php $attributes = $__attributesOriginal4c8712d109ee532d154e34556ce7da7e; ?>
<?php unset($__attributesOriginal4c8712d109ee532d154e34556ce7da7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c8712d109ee532d154e34556ce7da7e)): ?>
<?php $component = $__componentOriginal4c8712d109ee532d154e34556ce7da7e; ?>
<?php unset($__componentOriginal4c8712d109ee532d154e34556ce7da7e); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/profil.blade.php ENDPATH**/ ?>