<?php $__env->startSection('title', 'Masuk — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'login'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page flex min-h-[76vh] items-center justify-center py-12">
    <div class="grid w-full max-w-5xl overflow-hidden rounded-3xl border border-soft surface shadow-2xl md:grid-cols-[.9fr_1.1fr]">
        <aside class="hero-image relative hidden min-h-[590px] flex-col justify-end p-10 md:flex"><div class="relative z-10"><p class="eyebrow">Jejak Fauna Kalimantan</p><h1 class="font-display mt-3 text-4xl text-white">Setiap perjalanan dimulai dari rasa ingin tahu.</h1><p class="mt-4 text-sm leading-6 text-white/70">Masuk untuk menyimpan spesies favorit dan mencatat cerita penemuanmu.</p></div></aside>
        <div class="p-6 sm:p-10">
            <a class="text-sm text-muted hover:text-fresh-grown" href="<?php echo e(route('home')); ?>">← Kembali ke beranda</a>
            <div class="mt-9"><p class="eyebrow">Selamat datang kembali</p><h2 class="font-display mt-2 text-3xl">Masuk ke akunmu</h2><p class="mt-2 text-sm text-muted">Gunakan akun demo untuk melihat tampilan profil.</p></div>
            <form class="mt-7 grid gap-4" data-auth-form novalidate>
                <label><span class="field-label">Alamat email</span><input class="field" type="email" name="email" placeholder="nama@email.com" autocomplete="email" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <label><span class="field-label">Kata sandi</span><input class="field" type="password" name="password" placeholder="Masukkan kata sandi" autocomplete="current-password" minlength="6" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <div class="flex justify-end"><a class="text-xs text-fresh-grown hover:underline" href="#lupa-password" data-toast="Fitur ini akan aktif setelah backend terhubung">Lupa kata sandi?</a></div>
                <button class="btn-primary mt-1 w-full" type="submit">Masuk <span aria-hidden="true">→</span></button>
                <p class="text-center text-xs text-muted">Belum punya akun? <a class="font-semibold text-fresh-grown hover:underline" href="<?php echo e(route('register')); ?>">Daftar sekarang</a></p>
            </form>
            <p class="mt-6 rounded-xl border border-azul-petroleo/30 bg-azul-petroleo/10 p-3 text-xs leading-5 text-muted">Demo UI: isi email dan kata sandi apa saja untuk berpindah ke tampilan akun lokal.</p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>