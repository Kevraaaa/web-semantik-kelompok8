<section
    <?php echo e($attributes->merge(['class' => "w-full max-w-7xl mx-auto p-4 sm:p-14 border-x border-dashed border-neutral-300 dark:border-white/[9%]"])); ?>

>
    <?php echo e($slot); ?>

</section>
<?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\vendor\laravel\framework\src\Illuminate\Foundation\resources\exceptions\renderer/components/section-container.blade.php ENDPATH**/ ?>