<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['eyebrow' => null, 'title', 'description' => null, 'action' => null, 'href' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['eyebrow' => null, 'title', 'description' => null, 'action' => null, 'href' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
    <div>
        <?php if($eyebrow): ?><p class="eyebrow"><?php echo e($eyebrow); ?></p><?php endif; ?>
        <h2 class="font-display mt-2 text-3xl leading-tight sm:text-4xl"><?php echo e($title); ?></h2>
        <?php if($description): ?><p class="mt-3 max-w-2xl text-sm leading-6 text-muted"><?php echo e($description); ?></p><?php endif; ?>
    </div>
    <?php if($action && $href): ?><a class="btn-secondary shrink-0" href="<?php echo e($href); ?>"><?php echo e($action); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
</div>
<?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/components/section-heading.blade.php ENDPATH**/ ?>