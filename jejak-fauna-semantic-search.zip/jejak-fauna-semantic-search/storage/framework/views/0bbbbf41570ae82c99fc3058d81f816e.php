<?php $__env->startSection('title', 'Daftar — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'register'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page flex min-h-[76vh] items-center justify-center py-12">
    <div class="grid w-full max-w-5xl overflow-hidden rounded-3xl border border-soft surface shadow-2xl md:grid-cols-[.9fr_1.1fr]">
        <aside class="hero-image relative hidden min-h-[630px] flex-col justify-end p-10 md:flex"><div class="relative z-10"><p class="eyebrow">Mari jaga bersama</p><h1 class="font-display mt-3 text-4xl text-white">Kenali lebih dekat. Jaga lebih lama.</h1><p class="mt-4 text-sm leading-6 text-white/70">Jadilah bagian dari komunitas yang menghargai alam liar dan pengetahuan lokal.</p></div></aside>
        <div class="p-6 sm:p-10">
            <a class="text-sm text-muted hover:text-fresh-grown" href="<?php echo e(route('home')); ?>">← Kembali ke beranda</a>
            <div class="mt-8"><p class="eyebrow">Buat akun</p><h2 class="font-display mt-2 text-3xl">Mulai perjalananmu</h2><p class="mt-2 text-sm text-muted">Pendaftaran pada demo ini hanya mengubah state di browser.</p></div>
            <form class="mt-6 grid gap-4" data-register-form novalidate>
                <label><span class="field-label">Nama lengkap</span><input class="field" type="text" name="name" placeholder="Nama kamu" autocomplete="name" minlength="2" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <label><span class="field-label">Alamat email</span><input class="field" type="email" name="email" placeholder="nama@email.com" autocomplete="email" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <label><span class="field-label">Kata sandi</span><input class="field" type="password" name="password" placeholder="Minimal 8 karakter" autocomplete="new-password" minlength="8" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <label><span class="field-label">Ulangi kata sandi</span><input class="field" type="password" name="password_confirmation" placeholder="Ulangi kata sandi" autocomplete="new-password" required><?php if (isset($component)) { $__componentOriginal45c27ef3e6d5d72689a68e0d58751167 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field-error','data' => ['name' => 'password_confirmation']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password_confirmation']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $attributes = $__attributesOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__attributesOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167)): ?>
<?php $component = $__componentOriginal45c27ef3e6d5d72689a68e0d58751167; ?>
<?php unset($__componentOriginal45c27ef3e6d5d72689a68e0d58751167); ?>
<?php endif; ?></label>
                <label class="flex items-start gap-2 text-xs leading-5 text-muted"><input class="mt-1 accent-fresh-grown" type="checkbox" name="consent" required><span>Saya setuju menggunakan platform ini dengan bertanggung jawab dan menjaga keselamatan satwa.</span></label>
                <p class="hidden text-xs text-rose-300" data-error-for="consent"></p>
                <button class="btn-primary w-full" type="submit">Buat akun <span aria-hidden="true">→</span></button>
                <p class="text-center text-xs text-muted">Sudah memiliki akun? <a class="font-semibold text-fresh-grown hover:underline" href="<?php echo e(route('login')); ?>">Masuk</a></p>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/auth/register.blade.php ENDPATH**/ ?>