<?php $__env->startSection('title', 'Eksplorasi Fauna — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'explore'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page pb-20 pt-12">
    <div class="mb-10 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p class="eyebrow">Katalog keanekaragaman</p><h1 class="font-display mt-2 text-4xl sm:text-5xl">Eksplorasi Fauna</h1><p class="mt-3 max-w-2xl text-sm leading-6 text-muted">Cari spesies dari nama, lalu persempit perjalananmu berdasarkan status konservasi, habitat, makanan, dan kelompok.</p></div><a class="btn-secondary" href="<?php echo e(route('map')); ?>">⌖ Lihat persebaran</a></div>
    <div class="grid gap-6 lg:grid-cols-[260px_1fr]">
        <aside id="filter-fauna" class="hidden h-fit rounded-2xl border border-soft surface p-5 lg:block">
            <div class="flex items-center justify-between"><h2 class="font-display text-xl">Filter fauna</h2><button class="text-xs text-fresh-grown hover:underline" type="button" data-filter-reset>Reset</button></div>
            <div class="mt-5 grid gap-5" data-filter-panel>
                <fieldset><legend class="mb-2 text-xs font-semibold">Status konservasi</legend><div class="grid gap-2 text-xs text-muted">
                    <?php $__currentLoopData = ['Kritis (CR)','Terancam (EN)','Rentan (VU)','Hampir Terancam (NT)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="flex items-center gap-2"><input class="accent-fresh-grown" type="checkbox" name="status" value="<?php echo e($status); ?>"><?php echo e($status); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div></fieldset>
                <fieldset><legend class="mb-2 text-xs font-semibold">Habitat</legend><div class="grid gap-2 text-xs text-muted">
                    <?php $__currentLoopData = ['Hutan hujan tropis','Hutan rawa gambut','Hutan mangrove','Sungai','Tepi sungai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="flex items-center gap-2"><input class="accent-fresh-grown" type="checkbox" name="habitat" value="<?php echo e($habitat); ?>"><?php echo e($habitat); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div></fieldset>
                <label class="grid gap-2 text-xs font-semibold">Jenis makanan<select class="field text-xs" data-filter-select="makanan"><option value="">Semua jenis</option><option>Buah</option><option>Ikan</option><option>Daun</option><option>Serangga</option></select></label>
                <label class="grid gap-2 text-xs font-semibold">Kelompok<select class="field text-xs" data-filter-select="kelompok"><option value="">Semua kelompok</option><option>Mamalia</option><option>Burung</option></select></label>
                <label class="grid gap-2 text-xs font-semibold">Ancaman<select class="field text-xs" data-filter-select="ancaman"><option value="">Semua ancaman</option><option>Kehilangan habitat</option><option>Perburuan</option><option>Fragmentasi hutan</option></select></label>
            </div>
        </aside>
        <div>
            <div class="rounded-2xl border border-soft surface p-4 sm:p-5" id="pencarian">
                <div class="flex flex-col gap-4 xl:flex-row xl:items-center">
                    <label class="relative flex-1"><span class="sr-only">Kata pencarian fauna</span><span class="absolute left-4 top-1/2 -translate-y-1/2 text-lg text-fresh-grown">⌕</span><input class="field pl-11" type="search" data-search-input placeholder="Cari nama atau nama ilmiah..." aria-label="Cari fauna"></label>
                    <label class="inline-flex cursor-pointer items-center gap-3 text-sm"><input type="checkbox" class="peer sr-only" data-semantic-toggle><span class="relative h-6 w-11 rounded-full bg-white/15 transition peer-checked:bg-fig-leaf"><span class="absolute left-1 top-1 size-4 rounded-full bg-white transition peer-checked:translate-x-5"></span></span><span>Pencarian Semantik</span></label>
                </div>
                <div class="mt-4 hidden rounded-xl border border-azul-petroleo/30 bg-azul-petroleo/10 p-4" data-semantic-help>
                    <p class="text-xs leading-5 text-muted">Tuliskan ciri atau habitat yang kamu ingat—kami akan mencocokkan kata kunci dengan data dummy fauna.</p>
                    <div class="mt-3 flex flex-wrap gap-2"><button class="query-example" data-query-example="hewan pemakan buah di hutan" type="button">hewan pemakan buah di hutan</button><button class="query-example" data-query-example="satwa air tawar di sungai" type="button">satwa air tawar di sungai</button><button class="query-example" data-query-example="primata yang hidup di rawa" type="button">primata yang hidup di rawa</button></div>
                </div>
                <div class="mt-4 flex flex-wrap gap-2" data-active-filters></div>
            </div>
            <div class="mt-7 flex items-center justify-between gap-3"><p class="text-sm text-muted" data-result-count>Memuat fauna...</p><button class="btn-secondary min-h-9 px-3 py-2 text-xs lg:hidden" type="button" data-mobile-filter>☷ Filter</button></div>
            <div class="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-3" data-fauna-results aria-live="polite">
                <?php for($i=0; $i<6; $i++): ?><?php if (isset($component)) { $__componentOriginalfd3a6f8f1730f577643b0c9e9ee5a212 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd3a6f8f1730f577643b0c9e9ee5a212 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skeleton-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('skeleton-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd3a6f8f1730f577643b0c9e9ee5a212)): ?>
<?php $attributes = $__attributesOriginalfd3a6f8f1730f577643b0c9e9ee5a212; ?>
<?php unset($__attributesOriginalfd3a6f8f1730f577643b0c9e9ee5a212); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd3a6f8f1730f577643b0c9e9ee5a212)): ?>
<?php $component = $__componentOriginalfd3a6f8f1730f577643b0c9e9ee5a212; ?>
<?php unset($__componentOriginalfd3a6f8f1730f577643b0c9e9ee5a212); ?>
<?php endif; ?><?php endfor; ?>
            </div>
            <div class="mt-5 hidden" data-fauna-empty><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['title' => 'Belum ada fauna yang cocok','description' => 'Coba ubah kata pencarian atau longgarkan pilihan filter.','action' => 'Lihat semua fauna','href' => ''.e(route('explore')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Belum ada fauna yang cocok','description' => 'Coba ubah kata pencarian atau longgarkan pilihan filter.','action' => 'Lihat semua fauna','href' => ''.e(route('explore')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></div>
            <div class="mt-5 hidden rounded-2xl border border-rose-300/20 bg-rose-950/20 p-5 text-sm text-rose-100" data-fauna-error role="alert">Data fauna belum dapat dimuat. Coba muat ulang halaman.</div>
        </div>
    </div>
</section>
<?php if (isset($component)) { $__componentOriginal4c8712d109ee532d154e34556ce7da7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c8712d109ee532d154e34556ce7da7e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.compare-bar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('compare-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c8712d109ee532d154e34556ce7da7e)): ?>
<?php $attributes = $__attributesOriginal4c8712d109ee532d154e34556ce7da7e; ?>
<?php unset($__attributesOriginal4c8712d109ee532d154e34556ce7da7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c8712d109ee532d154e34556ce7da7e)): ?>
<?php $component = $__componentOriginal4c8712d109ee532d154e34556ce7da7e; ?>
<?php unset($__componentOriginal4c8712d109ee532d154e34556ce7da7e); ?>
<?php endif; ?>
<div class="fixed inset-0 z-[60] hidden bg-black/70 p-4 lg:hidden" data-filter-drawer>
    <div class="ml-auto h-full w-full max-w-sm overflow-y-auto rounded-2xl border border-soft surface p-5">
        <div class="flex items-center justify-between"><h2 class="font-display text-xl">Filter fauna</h2><button type="button" class="text-2xl" data-filter-close aria-label="Tutup filter">×</button></div>
        <div class="mt-4 grid gap-5" data-filter-drawer-content></div>
        <button class="mt-4 w-full text-left text-xs text-fresh-grown" type="button" data-filter-reset-mobile>Reset filter</button>
        <button class="btn-primary mt-5 w-full" type="button" data-filter-close>Lihat hasil</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/eksplorasi/index.blade.php ENDPATH**/ ?>