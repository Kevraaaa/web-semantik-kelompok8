<?php $__env->startSection('title', 'Knowledge Graph — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'graph'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page pb-20 pt-10">
    <p class="eyebrow">Jalinan ekosistem</p><h1 class="font-display mt-2 text-4xl sm:text-5xl">Knowledge Graph</h1><p class="mt-3 max-w-3xl text-sm leading-6 text-muted">Telusuri hubungan fauna dengan habitat, makanan, ekosistem, dan ancaman. Pilih sebuah simpul untuk melihat tetangganya.</p>
    <div class="mt-7 grid gap-5 xl:grid-cols-[1fr_320px]">
        <div class="overflow-hidden rounded-3xl border border-soft surface p-3">
            <div class="mb-3 flex flex-col gap-3 sm:flex-row">
                <label class="relative flex-1"><span class="sr-only">Cari node graph</span><span class="absolute left-3 top-1/2 -translate-y-1/2 text-fresh-grown">⌕</span><input class="field pl-9" data-graph-search placeholder="Cari fauna, habitat, atau makanan..."></label>
                <div class="flex gap-2"><button class="btn-secondary px-3 py-2" data-graph-zoom="in" type="button" aria-label="Perbesar">＋</button><button class="btn-secondary px-3 py-2" data-graph-zoom="out" type="button" aria-label="Perkecil">−</button><button class="btn-secondary px-3 py-2 text-xs" data-graph-reset type="button">Atur ulang</button></div>
            </div>
            <div class="network-wrap h-[620px] min-h-[420px] rounded-2xl bg-[#182719]" data-graph aria-label="Graf interaktif hubungan fauna" role="application"></div>
        </div>
        <aside class="grid content-start gap-4">
            <div class="rounded-2xl border border-soft surface p-5"><h2 class="font-display text-xl">Legenda node</h2><ul class="mt-4 grid gap-3 text-xs text-muted"><li><span class="legend-dot bg-fresh-grown"></span>Fauna Kalimantan</li><li><span class="legend-dot bg-fig-leaf"></span>Fauna</li><li><span class="legend-dot bg-azul-petroleo"></span>Habitat / ekosistem</li><li><span class="legend-dot bg-amber-700"></span>Makanan</li><li><span class="legend-dot bg-rose-900"></span>Ancaman</li></ul></div>
            <div class="rounded-2xl border border-soft surface p-5"><h2 class="font-display text-xl">Filter relasi</h2><div class="mt-4 grid gap-2 text-xs text-muted"><?php $__currentLoopData = ['hidupDi'=>'hidupDi','memakan'=>'memakan','bagianDari'=>'bagianDari','terancamOleh'=>'terancamOleh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="flex items-center gap-2"><input class="accent-fresh-grown" type="checkbox" value="<?php echo e($type); ?>" data-graph-relation checked><?php echo e($label); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div>
            <div class="rounded-2xl border border-soft surface p-5" data-graph-detail><p class="eyebrow">Detail simpul</p><h2 class="font-display mt-2 text-xl" data-graph-detail-title>Pilih sebuah simpul</h2><p class="mt-2 text-sm leading-6 text-muted" data-graph-detail-text>Relasi terdekat akan disorot di dalam graf.</p><a class="mt-4 hidden text-sm font-semibold text-fresh-grown" data-graph-detail-link href="#">Lihat detail fauna →</a></div>
            <div class="text-xs leading-5 text-muted"><span class="text-amber-200">Catatan:</span> relasi di sini bersifat ilustratif dan memerlukan validasi sumber ilmiah sebelum digunakan sebagai fakta.</div>
        </aside>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/knowledge-graph.blade.php ENDPATH**/ ?>