<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status' => 'Belum dinilai']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status' => 'Belum dinilai']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $badgeColor = match ($status) {
        'Kritis (CR)' => 'bg-rose-900/40 text-rose-200',
        'Terancam (EN)' => 'bg-orange-900/40 text-orange-200',
        'Rentan (VU)' => 'bg-amber-900/35 text-amber-100',
        'Hampir Terancam (NT)' => 'bg-lime-900/35 text-lime-200',
        default => 'bg-azul-petroleo/30 text-sky-100',
    };
?>
<span <?php echo e($attributes->merge(['class' => "inline-flex rounded-full px-2.5 py-1 text-[.67rem] font-semibold {$badgeColor}"])); ?>><?php echo e($status); ?></span>
<?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/components/status-badge.blade.php ENDPATH**/ ?>