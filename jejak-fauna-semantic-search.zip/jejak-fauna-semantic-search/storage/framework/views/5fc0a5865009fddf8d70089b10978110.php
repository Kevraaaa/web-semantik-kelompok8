<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'description', 'action' => null, 'href' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'description', 'action' => null, 'href' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="rounded-2xl border border-dashed border-soft px-6 py-12 text-center">
    <span class="mx-auto grid size-14 place-items-center rounded-full bg-fig-leaf/20 text-2xl text-fresh-grown" aria-hidden="true">⌕</span>
    <h3 class="font-display mt-4 text-xl"><?php echo e($title); ?></h3><p class="mx-auto mt-2 max-w-md text-sm leading-6 text-muted"><?php echo e($description); ?></p>
    <?php if($action && $href): ?><a class="btn-primary mt-5" href="<?php echo e($href); ?>"><?php echo e($action); ?></a><?php endif; ?>
</div>
<?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/components/empty-state.blade.php ENDPATH**/ ?>