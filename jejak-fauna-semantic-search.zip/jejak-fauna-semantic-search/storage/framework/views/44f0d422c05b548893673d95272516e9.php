<?php $__env->startSection('title', 'Bandingkan Fauna — Jejak Fauna Kalimantan'); ?>
<?php $__env->startSection('page', 'compare'); ?>
<?php $__env->startSection('content'); ?>
<section class="container-page min-h-[70vh] pb-20 pt-12">
    <p class="eyebrow">Lihat perbedaan dan persamaan</p><h1 class="font-display mt-2 text-4xl sm:text-5xl">Bandingkan Fauna</h1><p class="mt-3 max-w-2xl text-sm leading-6 text-muted">Pilih 2–3 fauna di katalog untuk membandingkan habitat, makanan, ancaman, dan ciri khasnya.</p>
    <div class="mt-8" data-compare-results aria-live="polite"></div>
    <div class="mt-8 hidden" data-compare-empty><?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['title' => 'Pilih fauna yang ingin dibandingkan','description' => 'Kembali ke katalog dan centang kotak Bandingkan pada dua atau tiga kartu fauna.','action' => 'Jelajahi fauna','href' => ''.e(route('explore')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pilih fauna yang ingin dibandingkan','description' => 'Kembali ke katalog dan centang kotak Bandingkan pada dua atau tiga kartu fauna.','action' => 'Jelajahi fauna','href' => ''.e(route('explore')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\_Ainuha\_Ainuha IT\_Semester03\Web_Semantik\web-semantik-kelompok8\jejak-fauna-semantic-search\resources\views/pages/bandingkan.blade.php ENDPATH**/ ?>